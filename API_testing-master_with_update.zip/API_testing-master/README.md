**Install**  
cd API_testing  
pip install -r requirements.txt

**Run**  
cd API_testing  
pytest
